﻿<# Script to Disable smart card authenication for Outlook Anyhwere

*DESCRIPTION:
If you have enabled smart card authentication for Outlook Anywhere and would like to disable same for any business requirements or due to any problems encountered after enabling smart card authentication, you can use this script to revert back the changes to disable smart card authentication for Outlook Anywhere in exchange server 2013.

*Follow the INSTRUCTIONS below to perform the task - AYOR...
--Save the downloaded script as ‘DisableOutlookSmartCardAuth.ps1’ on your desired location (e.g.: ‘<Exchange install drive>:\Program Files\Microsoft\Exchange Server\V15\Scripts\’)
-Launch Exchange Management Shell and navigate to above saved path (e.g.: ‘<Exchange install drive>:\Program Files\Microsoft\Exchange Server\V15\Scripts\’)
-Run ‘.\DisableOutlookSmartCardAuth.ps1’

--Post running the script, delete and then recreate IIS Binding (...443). And ensure a valid SSL certificate is selected (IIS –> Default Web Site –> Bindings… – ‘https_ipport=0.0.0.0:443’)
--Reboot the Exchange Server.
--Repeat the same on all required exchange servers with CAS role.
--Also navigate to ‘HKEY_CURRENT_USER\Software\Microsoft\Office\15.0\Outlook\RPC’ and remove ‘EnableSmartcard’ – DWORD-32bit value, from client PC.

***Caution: Changes are made in IIS, application host configurations and registries… (BACKUP Recommended) ||| Please be aware that this disables Client Certificate authentication on IIS root/server-level.

*More Info: https://social.technet.microsoft.com/wiki/contents/articles/36604.exchange-server-2013-disable-smart-card-authentication-for-outlook-anywhere.aspx 
*Author: Krishna Kumar T (@KrishKT) #>

# Script Begins
# Globals
$ComputerName = [string]$Env:computername
$SetupRegistryPath = Get-ItemProperty -path ‘HKLM:SOFTWARE\Microsoft\ExchangeServer\v15\Setup’
$ExchangeInstallPath = $SetupRegistryPath.MsiInstallPath
$AutoDiscoverPath =  “Default Web Site/Autodiscover”
$EwsPath = “Default Web Site/EWS”
$EcpPath = “Default Web Site/ECP”
$OabPath = “Default Web Site/OAB”
$MapiPath = “Default Web Site/Mapi”
# Initialize IIS metabase management object
$InitWebAdmin = [System.Reflection.Assembly]::LoadWithPartialName(“Microsoft.Web.Administration”)
$Iis = new-object Microsoft.Web.Administration.ServerManager
# Changes/removes a registry value under HKLM\Software\Microsoft\Rpc\RpcProxy to disable RpcWithCert
function DisableRpcWithCert
{
    $registry = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey(‘LocalMachine’, ‘.’)
    $RpcProxyKey = $registry.OpenSubKey(“Software\Microsoft\Rpc\RpcProxy”, $true)
    $RpcProxyKey.SetValue(“EnableRpcWithCert”, 0)
    Write-Output “Registry updated, servicelet should disable RpcWithCert”
}
# Updates path SSL Flags and disables the client-cert AD mapping
function DisableClientCertAuthForPath ([string]$IisPath)
{
    Write-Output “Disabling Require-Client-Certs + AD Cert Mapping for: $IisPath.”
    $config = $Iis.GetApplicationHostConfiguration();
    # Set SslFlags to require SSL and ignore client certificate
    $accessSection = $config.GetSection(“system.webServer/security/access”, $IisPath)
    $accessSection[“sslFlags”] = “Ssl, Ssl128”
    # Disable certificate-to-AD object mapping
    $clientCertificateMappingAuthenticationSection = $config.GetSection(“system.webServer/security/authentication/clientCertificateMappingAuthentication”, $IisPath)
    $clientCertificateMappingAuthenticationSection[“enabled”] = $false
    $Iis.CommitChanges()
}
# Updates path to disable client-cert AD mapping
function DisableAdClientCertAuthForPath([string]$IisPath)
{
    $config = $Iis.GetApplicationHostConfiguration();
    if ($IisPath -eq “”)
    {
        Write-Output “Disabling AD Cert Mapping feature from IIS.”
        $clientCertificateMappingAuthenticationSection = $config.GetSection(“system.webServer/security/authentication/clientCertificateMappingAuthentication”)
    }
    else
    {
        Write-Output “Disabling AD Cert Mapping for: $IisPath.”
        $clientCertificateMappingAuthenticationSection = $config.GetSection(“system.webServer/security/authentication/clientCertificateMappingAuthentication”, $IisPath)
    }
    $clientCertificateMappingAuthenticationSection[“enabled”] = $false
    $Iis.CommitChanges()
}
# Removes OAB auth module by updating web.config for OAB virtual directory
function UpdateOabWebConfig()
{
    if (Get-WebManagedModule -PSPath “iis:\sites\Default Web Site\OAB” -Name Microsoft.Exchange.OABAuth)
    {
       Write-Output “OABAuthModule is present in OAB’s web.config.”
       Begin-WebCommitDelay
       Remove-WebManagedModule -PSPath “iis:\sites\Default Web Site\OAB” -Name “Microsoft.Exchange.OABAuth”
       Write-Output “Removed OABAuthModule from OAB’s web.config.”
       End-WebCommitDelay
    }
   }
# Look for SslBinding’s DefaultFlags and update as necessary
function FixSslDefaultFlags
{
    $registry = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey(‘LocalMachine’, ‘.’)
            # Need to reset value to $HTTP_SERVICE_CONFIG_SSL_FLAG_USE_DS_MAPPER and then restart IIS and HTTP.SYS
            Write-Output “SChannel AD certificate mapping registry setting needs to be updated. Shutting down IIS and HTTP.SYS.”
            iisreset /stop
            net stop http -force
            $defaultSslBinding = $registry.OpenSubKey(“SYSTEM\\CurrentControlSet\\services\\HTTP\\Parameters\\SslBindingInfo\\0.0.0.0:443”, $true)
            $defaultSslBinding.SetValue(“defaultflags”, 0)
            Write-Output “Registry updated, Restarting IIS and HTTP.SYS.”
            iisreset /start
}
# Look for valid port entries
function FixValidPorts
{
    $registry = [Microsoft.Win32.RegistryKey]::OpenRemoteBaseKey(‘LocalMachine’, ‘.’)
    $rpcProxyKey = $registry.OpenSubKey(“SOFTWARE\\Microsoft\\Rpc\\RpcProxy”)
    if ($rpcProxyKey -eq $Null)
    {
        # RPC/HTTP component is not correctly installed
        Write-Warning “RPC over HTTP Proxy feature is not correctly installed.  Please use Server Manager to reinstall this Windows Feature.”
        break
    }
    $validPorts = $rpcProxyKey.GetValue(“Validports_Autoconfig_Exchange”)
    if ($validPorts -eq $null)
    {
        # Enable-OutlookAnywhere was likely only recently enabled, adding stub value and restart dependent services
        $rpcProxyKey = $registry.OpenSubKey(“SOFTWARE\\Microsoft\\Rpc\\RpcProxy”, $true)
        $rpcProxyKey.SetValue(“Validports_Autoconfig_Exchange”, “”)  # set a stub value
        restart-service MSExchangeServiceHost
        restart-service MSExchangeFBA
    }
}
# Main
Write-Output “Disables Smart Card Authentication for Outlook Anywhere”
Write-Output “Configuring authentication for Outlook Anywhere on $ComputerName…” “”
# Test for Outlook Anywhere on current machine
if (Get-OutlookAnywhere -Server $ComputerName)
{
    Write-Output “Outlook Anywhere is configured on current machine.”
    FixValidPorts
}
else
{
    Write-Warning “Enable-OutlookAnywhere must be run before configuring authentication. Exiting.”
    break
}
# IIS: Disables server-wide Client certificate-to-AD authentication mapping
DisableAdClientCertAuthForPath (“”)                                    # Global
DisableClientCertAuthForPath($AutoDiscoverPath)                        # AutoDiscover
DisableClientCertAuthForPath($EwsPath)                                 # EWS
DisableClientCertAuthForPath($EcpPath)                                 # ECP
DisableClientCertAuthForPath($OabPath)                                 # OAB
DisableClientCertAuthForPath($MapiPath)                                # Mapi
# IIS: Outlook Anywhere: Disables Client certificate-to-AD authentication mapping
DisableRpcWithCert
# Check on Schannel settings to ensure the DefaultFlags
FixSslDefaultFlags
# Update OAB add web.config to add OABAuth module
UpdateOabWebConfig
Write-Output “Done! $ComputerName now has default Outlook Anywhere settings and no longer configured with smart card/client certificate authentication.”
$a=$Iis.Dispose() 
# End of Script.